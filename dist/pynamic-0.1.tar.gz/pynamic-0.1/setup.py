from distutils.core import setup

setup(name='pynamic', version='0.1', py_modules=['pynamic'])
